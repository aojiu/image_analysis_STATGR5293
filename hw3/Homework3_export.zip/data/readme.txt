TR=2.5 seconds

in the label.mat
label 1 means Rest (fixation) which has 94 volumes
label 2 means Finger movement which has 30 volumes
label 3 means Lips movement which has 30 volumes
label 4 means Foot movement which has 30 volumes



